﻿using System;

namespace ProjetFinale.Models
{
    public class Tache : ElementSuivi
    {
        public string Description { get; set; }
        public bool EstTerminee { get; set; }
    }
}
