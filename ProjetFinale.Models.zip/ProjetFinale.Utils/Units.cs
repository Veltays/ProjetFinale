﻿namespace ProjetFinale.Utils
{
    public enum WeightUnit { KG, LBS }
    public enum HeightUnit { CM, INCH }
}